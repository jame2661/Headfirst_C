int checksum(char* message);


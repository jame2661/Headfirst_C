void encrypt(char *message);


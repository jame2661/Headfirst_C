void display_calories(float weight, float distance, float coeff);

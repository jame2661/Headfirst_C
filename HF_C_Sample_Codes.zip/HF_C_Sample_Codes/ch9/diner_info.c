#include <stdio.h>
#include <stdlib.h>

int main(int argc, char* argv[])
{
	printf("식사 인원: %s\n", argv[1]);
	printf("주스: %s\n", getenv("JUICE"));

	return 0;
}


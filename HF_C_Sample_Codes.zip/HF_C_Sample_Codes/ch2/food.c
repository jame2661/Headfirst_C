#include <stdio.h>

int main()
{
	char food[5];
	printf("좋아하는 음식 이름을 입력하세요: ");
	scanf("%s", food);
	printf("좋아하는 음식: %s\n", food);
}

